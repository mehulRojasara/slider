function setFullScreen() {
  var fHeight = $(window).outerHeight();
  var fWidth = $(window).outerWidth();
  $(".full-screen").css({ height: fHeight, width: fWidth });
}

// close menu
$(".btn-menu-open").on("click", function() {
  $(".main-menu").addClass("show");
});
$(".btn-close").on("click", function() {
  $(".main-menu").removeClass("show");
});

$(document).ready(function() {
  setFullScreen();
  // slider initilisation
  var verticalSlider = new Swiper(".vertical-slider", {
    allowTouchMove: true,
    direction: "vertical",
    speed: 800,
    slidesPerView: 1,
    // autoplay: {
    //   delay: 3000
    // },
    spaceBetween: 0,
    preventClicks: false,
    preloadImages: true,
    updateOnImagesReady: true,
    slideVisibleClass: "slide-visible",
    mousewheel: {
      mousewheel: true,
      sensitivity: 1,
      releaseOnEdges: true
    },
    navigation: {
      nextEl: ".vertical-slider-button-next",
      prevEl: ".vertical-slider-button-prev"
    },
    pagination: {
      el: ".vertical-slider-pagination",
      clickable: true
    },
    on: {
      resize: function() {
        verticalSlider.update();
      }
      // {
      //   animate
      // }
    }
  });

  $(window).resize(function() {
    setTimeout(function() {
      setFullScreen();
      if ($(".vertical-slider-pagination").length > 0 && verticalSlider) {
        verticalSlider.update;
      }
    }, 500);
  });

  // wow animation
  var wow = new WOW({
    boxClass: "wow", // default
    animateClass: "animate",
    offset: 0, // default
    mobile: true, // default
    live: true // default
  });
  wow.init();
});
