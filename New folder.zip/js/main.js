function setFullScreen() {
  var fHeight = $(window).outerHeight();
  var fWidth = $(window).outerWidth();
  $(".full-screen").css({ height: fHeight, width: fWidth });
}
$(document).ready(function() {
  setFullScreen();
  // slider initilisation
  var verticalSlider = new Swiper(".vertical-slider", {
    allowTouchMove: true,
    direction: "vertical",
    slidesPerView: 1,
    spaceBetween: 0,
    preventClicks: false,
    preloadImages: true,
    updateOnImagesReady: true,
    mousewheel: {
      mousewheel: true,
      sensitivity: 1,
      releaseOnEdges: true
    },
    navigation: {
      nextEl: ".vertical-slider-button-next",
      prevEl: ".vertical-slider-button-prev"
    },
    pagination: {
      el: ".vertical-slider-pagination",
      clickable: true
    },
    on: {
      resize: function() {
        verticalSlider.update();
      }
    }
  });

  $(window).resize(function() {
    setTimeout(function() {
      setFullScreen();
      if ($(".vertical-slider-pagination").length > 0 && verticalSlider) {
        verticalSlider.update;
      }
    }, 500);
  });
});
